#pragma once

#include <iostream>
#include <cmath>
#include <string>
#include <fstream>
#include <vector>
#include <armadillo>

const double sigma_Au = 2.951;
const double epsilon_Au = 5.29;
const int n_Au = 79;

//hw1_1 functions
struct Atom {
    int atomic_number;
    double x, y, z;
};


double Rij(Atom& a1, Atom& a2){
    double dx = a1.x - a2.x;
    double dy = a1.y - a2.y;
    double dz = a1.z - a2.z;
    return std::sqrt(dx*dx + dy*dy + dz*dz);
}

double Eij(double rij) {
    double sr = sigma_Au / rij;
    double sr12 = std::pow(sr, 12);
    double sr6 = std::pow(sr, 6);
    return epsilon_Au * (sr12 - 2.0 * sr6);
}

double ELJ(std::vector<Atom>& atoms) {
    double E = 0.0;
    for (size_t i = 0; i < atoms.size(); i++) {
        for (size_t j = i + 1; j < atoms.size(); j++) {
            double rij = Rij(atoms[i], atoms[j]);
            E += Eij(rij);
        }
    }
    return E;
}

std::vector<Atom> load_atoms(const std::string& filename) {
    std::ifstream infile(filename);
    int n_atoms;
    infile >> n_atoms;
    std::vector<Atom> atoms;
    for (int i = 0; i < n_atoms; i++) {
        Atom atom;
        infile >> atom.atomic_number >> atom.x >> atom.y >> atom.z;
        if (atom.atomic_number != n_Au) {
            throw std::runtime_error("Error: Only Au atoms supported");
        }
        atoms.push_back(atom);
    }

    return atoms;
}


//hw1_2 functions
struct Force {
    double x, y, z;
};

std::vector<Force> Fi_analytical(std::vector<Atom>& atoms) {
    std::vector<Force> forces(atoms.size(), {0.0, 0.0, 0.0});
    for (size_t i = 0; i < atoms.size(); i++) {
        for (size_t j = i + 1; j < atoms.size(); j++) {
            double dx = atoms[i].x - atoms[j].x;
            double dy = atoms[i].y - atoms[j].y;
            double dz = atoms[i].z - atoms[j].z;
            double rij = Rij(atoms[i], atoms[j]);
            double f_magnitude = -1 * epsilon_Au * (-12.0 * std::pow(sigma_Au, 12) / std::pow(rij, 13) + 12.0 * std::pow(sigma_Au, 6) / std::pow(rij, 7));
            double Fx = f_magnitude * dx / rij;
            double Fy = f_magnitude * dy / rij;
            double Fz = f_magnitude * dz / rij;
            forces[i].x += Fx; forces[i].y += Fy; forces[i].z += Fz;
     
            forces[j].x -= Fx; forces[j].y -= Fy; forces[j].z -= Fz;
        }
    }
    return forces;
}

std::vector<Force> Fi_forward(std::vector<Atom>& atoms, double h) {
    std::vector<Force> forces(atoms.size(), {0.0, 0.0, 0.0});
    for (size_t i = 0; i < atoms.size(); i++) {
        double elj = ELJ(atoms);
        for (int dim = 0; dim < 3; dim++) {
            if (dim == 0) atoms[i].x += h;
            else if (dim == 1) atoms[i].y += h;
            else atoms[i].z += h;
            double elj_h = ELJ(atoms);
            double F = -1 * (1/h) * (elj_h - elj);
            if (dim == 0) atoms[i].x -= h;
            else if (dim == 1) atoms[i].y -= h;
            else atoms[i].z -= h;
            if (dim == 0) forces[i].x = F;
            else if (dim == 1) forces[i].y = F;
            else forces[i].z = F;
       }
    }
    return forces;
}

std::vector<Force> Fi_central(std::vector<Atom>& atoms, double h) {
    std::vector<Force> forces(atoms.size(), {0.0, 0.0, 0.0});
    for (size_t i = 0; i < atoms.size(); i++) {
        for (int dim = 0; dim < 3; dim++) {
            if (dim == 0) atoms[i].x += h;
            else if (dim == 1) atoms[i].y += h;
            else atoms[i].z += h;
            double elj_plus_h = ELJ(atoms);
            if (dim == 0) atoms[i].x -= 2*h;
            else if (dim == 1) atoms[i].y -= 2*h;
            else atoms[i].z -= 2*h;
            double elj_minus_h = ELJ(atoms);
            if (dim == 0) atoms[i].x += h;
            else if (dim == 1) atoms[i].y += h;
            else atoms[i].z += h;
            double F = -1 * (1/(2*h)) * (elj_plus_h - elj_minus_h);
            if (dim == 0) forces[i].x = F;
            else if (dim == 1) forces[i].y = F;
            else forces[i].z = F;
       }
    }
    return forces;
}

//hw1_3a functions
double F_norm (std::vector<Force>& forces) {
    double sum = 0.0;
    for (auto& f : forces) {
        sum += f.x * f.x + f.y * f.y + f.z * f.z;
    }
    return std::sqrt(sum);
}

std::vector<Atom> steepest_descent(std::vector<Atom>& atoms, double step_size_central, double step_size_steep, double tol, int max_iter=1000) {
    std::cout << "Start steepest descent with central difference force.\n";
    double elj = ELJ(atoms);
    int iter = 0;
    while (iter < max_iter) {
        std::vector<Force> forces = Fi_central(atoms, step_size_central);
        double forces_norm = F_norm(forces);
        if (forces_norm < tol) break;
        double E_min = elj;
        double step_min = 0.0;
        for (double step = step_size_steep; step > 0.0001 * step_size_steep; step *= 0.9) {
            std::vector<Atom> updated_atoms = atoms;
            for (size_t i = 0; i < atoms.size(); i++) {
                updated_atoms[i].x += step * forces[i].x;
                updated_atoms[i].y += step * forces[i].y;
                updated_atoms[i].z += step * forces[i].z;
            }
            double updated_elj = ELJ(updated_atoms);
            if (updated_elj < E_min) {
                E_min = updated_elj;
                step_min = step;
            }
        }
        for (size_t i = 0; i < atoms.size(); i++) {
            atoms[i].x += step_min * forces[i].x;
            atoms[i].y += step_min * forces[i].y;
            atoms[i].z += step_min * forces[i].z;
            }
        elj = E_min;
        iter++;
    }
    std::cout << "Total iterations: " << iter << "\n";
    std::cout << "Final energy: " << elj << "\n";
    return atoms;
}

//hw1_3b functions
std::vector<Atom> atom_position_update(std::vector<Atom>& atoms, std::vector<Force>& forces, double step) {
    std::vector<Atom> updated_atoms = atoms;
    for (size_t i = 0; i < atoms.size(); i++) {
        updated_atoms[i].x += step * forces[i].x;
        updated_atoms[i].y += step * forces[i].y;
        updated_atoms[i].z += step * forces[i].z;
    }
    return updated_atoms;
}

double best_step_size(std::vector<Atom>& atoms, std::vector<Force>& forces, double a, double b, double tol) {
    const double phi = (1 + std::sqrt(5)) / 2;
    double c = b - (b - a) / phi;
    double d = a + (b - a) / phi;
    while (std::abs(b - a) > tol) {
        std::vector<Atom> atoms_c = atom_position_update(atoms, forces, c);
        std::vector<Atom> atoms_d = atom_position_update(atoms, forces, d);
        double Ec = ELJ(atoms_c);
        double Ed = ELJ(atoms_d);
        if (Ec < Ed) {
            b = d;
        } 
        else {
            a = c;
        }
        c = b - (b - a) / phi;
        d = a + (b - a) / phi;
    }
    return (a + b) / 2;
}

std::vector<Atom> golden_section(std::vector<Atom>& atoms, double step_size_central, double step_size_golden, double tol, int max_iter=1000) {
    double elj = ELJ(atoms);
    int iter = 0;
    double previous_elj = elj + 10 * tol;
    std:: cout << "Start steepest descent with golden section line search using central difference force\n";
    while (iter < max_iter) {
        std::vector<Force> f_central = Fi_central(atoms, step_size_central);
        double forces_norm = F_norm(f_central);
        if (forces_norm < tol) break;
        for (auto& f : f_central) {
            f.x /= forces_norm;
            f.y /= forces_norm;
            f.z /= forces_norm;
        }
        std::cout << "Start golden section search\n";
        double step_min = best_step_size(atoms, f_central, 0.0, step_size_golden, tol);
        atoms = atom_position_update(atoms, f_central, step_min);
        elj = ELJ(atoms);
        if (std::abs(previous_elj - elj) < 0.1*tol) break;
        previous_elj = elj;
        std::cout << "new point\n";
        for (const auto& atom : atoms) {
            std::cout << atom.atomic_number << "(" 
            << atom.x << ", "
            << atom.y << ", "
            << atom.z << ")" << "\n";
        }
        std::cout << "current energy: " << elj << "\n";
        for (auto& f : f_central) {
            std::cout << f.x << " " << f.y << " " << f.z << "\n";
        }
        iter++;
    }
    std::cout << "Total iterations: " << iter << "\n";
    std::cout << "Final energy: " << elj << "\n";
    return atoms;
}