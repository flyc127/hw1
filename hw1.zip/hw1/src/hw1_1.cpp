#include <iostream>
#include "hw1_header.hpp"


int main(int argc, char** argv){
    std::string filename = argv[1];
    std::vector<Atom> atoms = load_atoms(filename);
    for (const auto& atom : atoms) {
        std::cout << atom.atomic_number << "(" 
        << atom.x << ", "
        << atom.y << ", "
        << atom.z << ")" << "\n";
    }
    double elj = ELJ(atoms);
    std::cout << "E_LJ = " << elj << std::endl;
    return 0;
}
