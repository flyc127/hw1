This is the starter code for HW1 and is intended to help you organize your work and provide you with some useful tools.

We are using Docker to provide a standardized computing environment for working on the homeworks. 
In a nutshell, using Docker allows you all to have access to the same versions of the libraries and dependencies needed for the homeworks. 
We've supplied a Docker _image_ that includes these dependencies; it acts as a template to create a _container_ in which you'll run your code.
Using the Docker container should (hopefully) be relatively straightforward. You'll need to download and install Docker desktop for your operating system. 
Then, in the root directory for homework 1, you can run `./interactive.sh` to run the Docker container in interactive mode.
Once in the container, you can build your code with `./build.sh`. Running `./clean.sh` clears the build directory.

We'll discuss this in greater detail next Monday during the compute lab, but feel free to email me if you have questions in the meantime at rachel_patterson@berkeley.edu.
