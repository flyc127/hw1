#include <iostream>
#include "hw1_header.hpp"


int main(int argc, char** argv){
    std::string filename = argv[1];
    std::vector<Atom> atoms = load_atoms(filename);
    double elj = ELJ(atoms);
    std::cout << "E_LJ = " << elj << "\n";
    std::vector<Force> f_analytical = Fi_analytical(atoms);
    std::cout << "F_LJ_analytical\n";
    for (auto& f : f_analytical) {
        std::cout << f.x << " " << f.y << " " << f.z << "\n";
    }
    std::vector<double> steps = {0.1, 0.01, 0.001, 0.0001};
    for (double h: steps) {
        std::cout << "Stepsize for finite difference:" << h << "\n";
        std::vector<Force> f_forward = Fi_forward(atoms, h);
        std::cout << "F_LJ_forward_difference\n";
        for (auto& f : f_forward) {
            std::cout << f.x << " " << f.y << " " << f.z << "\n";
        }
        std::vector<Force> f_central = Fi_central(atoms, h);
        std::cout << "F_LJ_central_difference\n";
        for (auto& f : f_central) {
            std::cout << f.x << " " << f.y << " " << f.z << "\n";
        }
    }
    return 0;
}