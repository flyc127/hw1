#include <iostream>
#include <vector>
#include "hw1_header.hpp"

int main(int argc, char** argv){
    std::string filename = argv[1];
    std::vector<Atom> atoms = load_atoms(filename);
    std::cout << "start steepest descent\n"; 
    double elj = ELJ(atoms);
    double step_size_central = 0.0001;
    double step_size_steep = 0.3;
    double tol = 0.01;
    std::cout << "Initial energy: " << elj << '\n';
    std::cout << "Step size for central difference is:" << step_size_central << ";Initial stepsize for steepest descent is:" << step_size_steep << "; Threshold for convergence in force is:" << tol << "\n";
    std::cout << "Analytical Force\n";
    std::vector<Force> f_analytical = Fi_analytical(atoms);
    for (auto& f : f_analytical) {
        std::cout << f.x << " " << f.y << " " << f.z << "\n";
    }
    std::cout << "Forward Difference Force\n";
    std::vector<Force> f_forward = Fi_forward(atoms, step_size_central);
    for (auto& f : f_forward) {
        std::cout << f.x << " " << f.y << " " << f.z << "\n";
    }  
    std::cout << "Central Difference Force\n";
    std::vector<Force> f_central = Fi_central(atoms, step_size_central);
    for (auto& f : f_central) {
        std::cout << f.x << " " << f.y << " " << f.z << "\n";
    }
    std::vector<Atom> opt_atoms = steepest_descent(atoms, step_size_central, step_size_steep, tol);
    std::cout << "Optimized structure:\n";
    for (const auto& atom : opt_atoms) {
        std::cout << atom.atomic_number << "(" 
        << atom.x << ", "
        << atom.y << ", "
        << atom.z << ")" << "\n";
    }
    return 0;
}