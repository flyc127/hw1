import pathlib
import subprocess
import shutil

BASE_DIR = pathlib.Path(__file__).parent.parent
INPUT_DIR = BASE_DIR / "sample_input"
OUTPUT_DIR = BASE_DIR / "student_output"
BINARY_DIR = BASE_DIR / "build/src"


def run_all_tests():
    if OUTPUT_DIR.exists():
        shutil.rmtree(OUTPUT_DIR)
    OUTPUT_DIR.mkdir(parents=True)
    
    for question_id in [f.name for f in BINARY_DIR.iterdir() if f.is_file() and "hw" in f.name]:
        input_subdir = INPUT_DIR / question_id
        output_subdir = OUTPUT_DIR / question_id
        executable_path = BINARY_DIR / question_id

        output_subdir.mkdir(parents=True, exist_ok=True)
        for test_file in input_subdir.iterdir():
            if test_file.is_file():

                output_path = output_subdir / test_file.name

                result = subprocess.run(args=[executable_path, test_file], capture_output=True, text=True)

                output_path.write_text(result.stdout)


if __name__ == "__main__":
    run_all_tests()